from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__)

# Load model and metadata
model = joblib.load("msrp_model/car_price_model.pkl")
features = joblib.load("msrp_model/features.pkl")

# Load encoders
encoders = {
    'Make': joblib.load("msrp_model/encoder_Make.pkl"),
    'Model': joblib.load("msrp_model/encoder_Model.pkl"),
    'Engine Fuel Type': joblib.load("msrp_model/encoder_Engine Fuel Type.pkl"),
    'Transmission Type': joblib.load("msrp_model/encoder_Transmission Type.pkl"),
    'Driven_Wheels': joblib.load("msrp_model/encoder_Driven_Wheels.pkl"),
    'Vehicle Size': joblib.load("msrp_model/encoder_Vehicle Size.pkl"),
    'Vehicle Style': joblib.load("msrp_model/encoder_Vehicle Style.pkl"),
}

# Load correct Make → Model mapping
make_model_map = joblib.load("msrp_model/make_model_map.pkl")
make_model_map = {k: sorted(list(v)) for k, v in make_model_map.items()}

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None
    dropdown_options = {
        field: list(encoder.classes_)
        for field, encoder in encoders.items() if field != 'Model'
    }

    if request.method == "POST":
        input_data = {}
        for field in features:
            value = request.form.get(field)
            if field in encoders:
                input_data[field] = encoders[field].transform([value])[0]
            else:
                input_data[field] = float(value)

        input_df = pd.DataFrame([input_data])[features]
        price = model.predict(input_df)[0]
        prediction = f"{int(price):,}"

    return render_template("index.html", options=dropdown_options, prediction=prediction)

@app.route("/get_models", methods=["POST"])
def get_models():
    make = request.json.get("make")
    return jsonify(make_model_map.get(make, []))

if __name__ == "__main__":
    app.run(debug=True)
