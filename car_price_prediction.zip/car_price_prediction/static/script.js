document.addEventListener("DOMContentLoaded", function () {
    const makeSelect = document.getElementById("make");
    const modelSelect = document.getElementById("model");
  
    makeSelect.addEventListener("change", () => {
      const selectedMake = makeSelect.value;
      if (!selectedMake) return;
  
      fetch("/get_models", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ make: selectedMake })
      })
      .then(response => response.json())
      .then(models => {
        modelSelect.innerHTML = `<option value="">Select Model</option>`;
        models.forEach(model => {
          const option = document.createElement("option");
          option.value = model;
          option.textContent = model;
          modelSelect.appendChild(option);
        });
      })
      .catch(err => console.error("Error loading models:", err));
    });
  });
  