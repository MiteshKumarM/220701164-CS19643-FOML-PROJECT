import pandas as pd
import numpy as np
import joblib
import os
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load the dataset
df = pd.read_csv("data.csv")

# Drop rows with missing target
df.dropna(subset=['MSRP'], inplace=True)

# Fill missing values
df['Engine Fuel Type'].fillna(df['Engine Fuel Type'].mode()[0], inplace=True)
df['Engine HP'].fillna(df['Engine HP'].mean(), inplace=True)
df['Engine Cylinders'].fillna(df['Engine Cylinders'].mean(), inplace=True)
df['Number of Doors'].fillna(df['Number of Doors'].mode()[0], inplace=True)
df['Market Category'].fillna("Unknown", inplace=True)

# Select features
features = [
    'Make', 'Model', 'Year', 'Engine Fuel Type', 'Engine HP', 'Engine Cylinders',
    'Transmission Type', 'Driven_Wheels', 'Number of Doors',
    'Vehicle Size', 'Vehicle Style', 'highway MPG', 'city mpg', 'Popularity'
]
target = 'MSRP'

X = df[features].copy()
y = df[target]

# Save Make → Model mapping BEFORE encoding
make_model_map = df.groupby('Make')['Model'].unique().to_dict()
os.makedirs("msrp_model", exist_ok=True)
joblib.dump(make_model_map, "msrp_model/make_model_map.pkl")

# Encode categorical features
label_encoders = {}
for column in X.select_dtypes(include='object').columns:
    le = LabelEncoder()
    X[column] = le.fit_transform(X[column])
    label_encoders[column] = le

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Evaluate
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
r2 = r2_score(y_test, y_pred)

print("\n📊 Evaluation:")
print("MAE :", round(mae, 2))
print("RMSE:", round(rmse, 2))
print("R²  :", round(r2, 4))

# Save model and encoders
joblib.dump(model, "msrp_model/car_price_model.pkl")
joblib.dump(list(X.columns), "msrp_model/features.pkl")
for col, le in label_encoders.items():
    joblib.dump(le, f"msrp_model/encoder_{col}.pkl")

